
import Card  from './Card.jsx';
import './App.css'

function App() {

  return (
    <>
      <Card />
    </>
  )
}

export default App
